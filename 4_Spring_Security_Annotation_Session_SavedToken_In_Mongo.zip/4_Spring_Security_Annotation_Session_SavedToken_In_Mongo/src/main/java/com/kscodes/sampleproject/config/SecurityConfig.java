package com.kscodes.sampleproject.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.security.authentication.encoding.ShaPasswordEncoder;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.authentication.SavedRequestAwareAuthenticationSuccessHandler;
import org.springframework.security.web.authentication.rememberme.InMemoryTokenRepositoryImpl;
import org.springframework.security.web.authentication.rememberme.JdbcTokenRepositoryImpl;
import org.springframework.security.web.authentication.rememberme.PersistentTokenRepository;

import com.kscodes.sampleproject.model.MyUserDetailServices;

// lop nay tuong duong noi dung trong spring-security.xml 

/*
 <!-- enable @PreAuthorize and PostAuthorize -->
	<global-method-security pre-post-annotations="enabled" />

	<http auto-config="false" use-expressions="true" >
	
        <!-- all privilege can access login page -->
	    <intercept-url pattern="/login" access="permitAll" />
	    
	    <!-- all privilege can access add page, exception ADMIN privilege -->
	    <intercept-url pattern="/add" access="hasRole('ROLE_ADMIN')" />
	    
	    <!-- Root privilege and Admin privilege can only access action2 page -->
	    <intercept-url pattern="/user" access="!hasRole('ROLE_ADMIN')" />	   	 
	    
	    <!-- Root privilege can only access action3 page  -->
	    <intercept-url pattern="/action3" access="hasRole('ROLE_ROOT')" />
	       
	    
		<!--  <intercept-url pattern="/login" access="permitAll" />  -->
		
		<form-login login-page="/login"
		            default-target-url="/success"
		            authentication-failure-url="/denied" 
		            username-parameter="j_username"
		            password-parameter="j_password"/>
		<logout     logout-success-url="/logout" />
		   
	</http>
	
	<authentication-manager alias="authenticationManager">
	  <authentication-provider user-service-ref="myUserDetailServices">
	   <password-encoder hash="plaintext" > </password-encoder>
	  </authentication-provider>
	</authentication-manager>	
	
 */

@Configuration   
@EnableWebSecurity // enalble spring security configuration
public class SecurityConfig extends WebSecurityConfigurerAdapter   {
//	@Autowired
	//DataSource dataSource;
	
	@Autowired
    PersistentTokenRepository repository;

	
	// tiem MyUserDetailServices 
	@Autowired
	private MyUserDetailServices myUserDetailServices;
	
	
	// Authorities
	@Autowired
	public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception{
		 auth.userDetailsService(myUserDetailServices); 
	}
	
	// in 27.4.2016, Quan and Phuc spend half of the day to fix error, that prolem is mis this line in SecurityConfig.java
	// Authentication
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		
		http.csrf().disable() //HTTP with Disable CSRF
		    .authorizeRequests()    
		    .antMatchers("/add").access("hasRole('ROLE_ADMIN')")
		    .antMatchers("/action3").access("hasRole('ROLE_USER')")
		    .antMatchers("/").permitAll()
		    .and()
		          .formLogin()
		          .loginProcessingUrl( "/j_spring_security_check" )
		          .loginPage("/login").permitAll()
		          .defaultSuccessUrl("/success")
		          .failureUrl("/login?error")		         
		          .usernameParameter("j_username")
		          .passwordParameter("j_password")
		     .and()
		          .exceptionHandling().accessDeniedPage("/action1")
		     .and()
		          .rememberMe().tokenRepository(repository) //If this is specified, “Persistent Token Approach” will be used. Defaults to “Simple Hash-Based Token Approach”.
		          .tokenValiditySeconds(12096000); // The expire date of “remember-me” cookie, in seconds	  		  		    
		    
	}
	
//	PersistentTokenRepository: interface, The abstraction used by JdbcTokenRepositoryImpl or PersistentTokenBasedRememberMeServices
//	to store the persistent login tokens for a user.
//	 JdbcTokenRepositoryImpl implements PersistentTokenRepository

/*
	@Bean
	public PersistentTokenRepository persistentTokenRepository() {
		JdbcTokenRepositoryImpl db = new JdbcTokenRepositoryImpl();	
		db.setDataSource(dataSource);
		return db;
		
	}
	
*/
//	SavedRequestAwareAuthenticationSuccessHandler implements AuthenticationSuccessHandler
	@Bean
	public SavedRequestAwareAuthenticationSuccessHandler savedRequestAwareAuthenticationSuccessHandler() {
		
		SavedRequestAwareAuthenticationSuccessHandler auth 
		                                           = new SavedRequestAwareAuthenticationSuccessHandler();
		auth.setTargetUrlParameter("targetUrl");
		return auth;
		
	}

}























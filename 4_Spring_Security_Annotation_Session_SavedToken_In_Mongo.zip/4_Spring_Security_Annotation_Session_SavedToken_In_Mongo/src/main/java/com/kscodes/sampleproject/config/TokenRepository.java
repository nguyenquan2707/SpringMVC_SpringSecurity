package com.kscodes.sampleproject.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface TokenRepository extends MongoRepository<Token, String> {

    	
    Token findBySeries(String series);
    Token findByUsername(String username);
}

package com.kscodes.sampleproject.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.data.mongodb.config.AbstractMongoConfiguration;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoDbFactory;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import com.mongodb.Mongo;
import com.mongodb.MongoClient;

//file nay tuong duong 
/*
 <bean id="mongo" class="org.springframework.data.mongodb.core.MongoFactoryBean">
        <property name="host" value="localhost" />
    </bean>     

    <bean id="mongoTemplate" class="org.springframework.data.mongodb.core.MongoTemplate"> 
        <constructor-arg name="mongo" ref="mongo" />
        <constructor-arg name="databaseName" value="myCollection" />
   </bean>
   
 */


@Configuration
@EnableMongoRepositories(basePackages = "com.kscodes.sampleproject.config")
public class SpringMongoConfig {
	
	@Bean
	public MongoDbFactory mongoDbFactory() throws Exception {
		MongoClient mongoClient = new MongoClient("localhost", 27017);
		return new SimpleMongoDbFactory( mongoClient, "myCollection");
	}
	
	@Bean(name="mongoTemplate")
	public MongoTemplate mongoTemplate() throws Exception {
		
		MongoTemplate mongoTemplate = new MongoTemplate(mongoDbFactory());
		return mongoTemplate;
	}
	
}

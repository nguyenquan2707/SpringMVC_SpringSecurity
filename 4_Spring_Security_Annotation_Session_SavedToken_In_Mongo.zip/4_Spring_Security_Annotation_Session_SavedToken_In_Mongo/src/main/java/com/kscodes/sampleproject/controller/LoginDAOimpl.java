package com.kscodes.sampleproject.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.security.access.prepost.PreAuthorize;

import com.kscodes.sampleproject.config.SpringMongoConfig;
import com.kscodes.sampleproject.model.Login;
import com.mongodb.BasicDBObject;
import com.kscodes.sampleproject.config.SpringMongoConfig;

@Configuration
public class LoginDAOimpl{
	/*
	@Autowired
	private MongoTemplate mongoTemplate;
	

	public Login findById(String id) {
		return mongoTemplate.findById(id, Login.class);
	}
	
	//search login info by username 
	public Login findByUsername(String userName) {
//		Criteria criteria = new Criteria("username", username);
//		Query query = new Query(criteria );
		Query query = new Query(Criteria.where("username").is(userName));
		return mongoTemplate.findOne(query, Login.class);
	}
	
	
	//save User into Mongo
	

	public void save(Login login) {
		// TODO Auto-generated method stub
		mongoTemplate.save(login);
		
	}
	*/
	
	@Autowired
	private SpringMongoConfig springMongoConfig;
	
	
	public Login findById(String id) throws Exception {
		return springMongoConfig.mongoTemplate().findById(id, Login.class);
	}
	
	
	public void save(Login login) throws Exception {
		springMongoConfig.mongoTemplate().save(login);
	}
	
	
	
	
	
	
	
	
	
	
	


}

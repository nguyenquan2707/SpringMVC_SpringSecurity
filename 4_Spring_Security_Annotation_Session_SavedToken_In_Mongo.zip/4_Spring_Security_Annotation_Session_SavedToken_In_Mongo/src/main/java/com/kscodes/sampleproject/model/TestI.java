package com.kscodes.sampleproject.model;

public interface TestI {
	public String returnString(String string);
}

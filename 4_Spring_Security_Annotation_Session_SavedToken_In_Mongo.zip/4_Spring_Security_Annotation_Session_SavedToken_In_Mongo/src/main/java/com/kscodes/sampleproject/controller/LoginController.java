package com.kscodes.sampleproject.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;
import com.kscodes.sampleproject.controller.LoginDAOimpl;

import com.kscodes.sampleproject.model.Login;

@Controller
public class LoginController {

	@Autowired 
	private LoginDAOimpl loginimpl;
	
	/*------------------>--------------------->---------------------->*/
	// spring security test
	
	@RequestMapping(value={"/","welcome**"},method=RequestMethod.GET)
	public ModelAndView welcome(){
	    ModelAndView model =new ModelAndView();
	    model.addObject("title", "Spring Security Hello World");
	    model.addObject("message", "This is welcome page");
	    model.setViewName("hello");
		
	    return model;
	}
	
	@RequestMapping(value="admin**",method=RequestMethod.GET)
	public ModelAndView addmin(){
		ModelAndView model = new ModelAndView();
		model.addObject("title","Spring Security Hello World");
		model.addObject("message","This is protected page!!!!");
		model.setViewName("admin");
		
		return model;
	}
	
	
	/*---------------->----------------->----------------->*/		
		
	// spring mvc test
	
	@RequestMapping("/login")
	public ModelAndView getLoginPage() {
		return new ModelAndView("login");
		
		
	}
	
	@RequestMapping("/add**")
	public ModelAndView getaddPage() {
		return new ModelAndView("add");
	}
	
	@RequestMapping(value="save",method=RequestMethod.GET)
	public ModelAndView savepage(){
		return new ModelAndView("save");
	}
	// save Login into Mongo
	
	@RequestMapping(value="processSave" , method = RequestMethod.POST)
	public String processSavesavePage(@ModelAttribute(value="login")Login login, BindingResult result) {
		
		try {
			loginimpl.save(login);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "success";
		
	}
	
	
	@RequestMapping("/user")
	public ModelAndView getuserpage(){
		return new ModelAndView("user");
	}
	
	@RequestMapping(value = "/success")
	public String menu(ModelMap map) {
		
		return "success";
	}
	
	@RequestMapping(value = "/logout")
	public String logoutpage(ModelMap map){
		
		return "logout";
	}
	
	@RequestMapping(value = "/denied")
	public String deniedpage(ModelMap map){
		
		return "denied";
	}
	
	@RequestMapping(value = "/action1")
	public String action1(ModelMap map){
		
		return "action1";
	}
	
	@RequestMapping(value = "/action2")
	public String action2(ModelMap map){
		
		return "action2";
	}
	
	@RequestMapping(value = "/action3")
	public String action3(ModelMap map){
		
		return "action3";
	}

}

package com.kscodes.sampleproject.model;

import java.util.ArrayList;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import com.kscodes.sampleproject.controller.LoginDAOimpl;

@Component
public class MyUserDetailServices implements UserDetailsService {
	
	@Autowired
	private LoginDAOimpl loginDAOimpl;
	

	// Class User cua Spring Security, dung de get usernam, password,authorize
//	private org.springframework.security.core.userdetails.User userDetails;
	
	
	
	 public List<GrantedAuthority> getAuthorities(Integer role) {
	        List<GrantedAuthority> authList = new ArrayList<GrantedAuthority>();
	        //neu role trong Mongo la 1, tra ve ROLE_ADMIN
	        if (role.intValue() == 1) {
	            authList.add(new SimpleGrantedAuthority("ROLE_ADMIN"));
	            authList.add(new SimpleGrantedAuthority("ROLE_USER"));
            //neu role trong Mongo la 2, tra ve ROLE_USER
	        } else if (role.intValue() == 2) {
	            authList.add(new SimpleGrantedAuthority("ROLE_USER"));
	        } else if (role.intValue() == 0) {
	        	authList.add(new SimpleGrantedAuthority("ROLE_ROOT"));
	        	authList.add(new SimpleGrantedAuthority("ROLE_ADMIN"));
		        authList.add(new SimpleGrantedAuthority("ROLE_USER"));
	        }
	        System.out.println(authList);
	        return authList;
	    }

//	 @Override
//	 public UserDetails loadUserByUsername(final String username) throws UsernameNotFoundException {
		//lay thong tin cua lop Login trong Mongo
//	 @Override
		public UserDetails loadUserByUsername(String username) 
			throws UsernameNotFoundException {
			System.out.println("DDDDDDDFDFDFDFDFDFDF");
	    Login login;
	    User userDetails = null;
		try {
			login = loginDAOimpl.findById(username);
			userDetails = new User(login.getUserName(),login.getPassword()
					,true,true,true,true,getAuthorities(Integer.valueOf(login.getRole())));
			
			return userDetails;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//dung ham Constructor cua lop User, de tra ve thong tin trong Mongo
		return userDetails;
	}
		
		

}

package com.kscodes.sampleproject.controller;

import com.kscodes.sampleproject.model.Login;

public interface LoginDAO {
	public Login findById();

}

package com.kscodes.sampleproject.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.kscodes.sampleproject.model.Login;


public class LoginDAOimpl{
	
	@Autowired
	private MongoTemplate mongoTemplate;
	
	public void addUser(Login login){
		if(!mongoTemplate.collectionExists(Login.class)){
			mongoTemplate.createCollection(Login.class);
		}
		mongoTemplate.insert(login);
		
	}

	public Login findById(String userName) {
		return mongoTemplate.findById(userName, Login.class);
	}

}

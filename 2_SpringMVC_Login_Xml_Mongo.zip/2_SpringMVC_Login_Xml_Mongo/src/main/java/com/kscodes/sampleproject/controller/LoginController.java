package com.kscodes.sampleproject.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;

import com.kscodes.sampleproject.model.Login;

@Controller
public class LoginController {
	
	@Autowired
	private LoginDAOimpl loginimpl;
	

	@RequestMapping("/login")
	public ModelAndView getLoginPage() {
		return new ModelAndView("login", "command", new Login());
	}

	@RequestMapping(value = "/processLogin", method = RequestMethod.POST)
	public ModelAndView processLogin(@ModelAttribute("login") Login login) {

		String userName = login.getUserName();
		String password = login.getPassword();
		
		String query1=loginimpl.findById(userName).getUserName();
		String query2=loginimpl.findById(userName).getPassword();
		if(query1==null){
			return new ModelAndView("error");
		}
		if (loginimpl.findById(userName).getUserName().equalsIgnoreCase(userName)
				&& loginimpl.findById(userName).getPassword().equalsIgnoreCase(password)) {
			ModelAndView mv = new ModelAndView("success");
			return mv;
		}       
		return null;
	}
        
	@RequestMapping("/add")
	public ModelAndView addUser() {
		return new ModelAndView("add", "command", new Login());
	} 
	@RequestMapping(value = "/processadd", method = RequestMethod.POST)  
	public ModelAndView processAddUser(@ModelAttribute("add") Login login) {
		login.setUserName(login.getUserName());
		login.setPassword(login.getPassword());
		loginimpl.addUser(login);
    	return new ModelAndView("success");  
    }
	
}

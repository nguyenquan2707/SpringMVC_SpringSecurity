package com.kscodes.sampleproject.model;

public class TestC implements TestI {

	public String returnString(String string) {
		return string;
	}

}

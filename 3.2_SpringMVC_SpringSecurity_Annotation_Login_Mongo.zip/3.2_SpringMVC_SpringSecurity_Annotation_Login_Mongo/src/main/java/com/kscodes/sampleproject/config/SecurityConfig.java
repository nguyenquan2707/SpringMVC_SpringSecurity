package com.kscodes.sampleproject.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.encoding.ShaPasswordEncoder;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

import com.kscodes.sampleproject.model.MyUserDetailServices;

// lop nay tuong duong noi dung trong spring-security.xml 

/*
 <!-- enable @PreAuthorize and PostAuthorize -->
	<global-method-security pre-post-annotations="enabled" />

	<http auto-config="false" use-expressions="true" >
	
        <!-- all privilege can access login page -->
	    <intercept-url pattern="/login" access="permitAll" />
	    
	    <!-- all privilege can access add page, exception ADMIN privilege -->
	    <intercept-url pattern="/add" access="hasRole('ROLE_ADMIN')" />
	    
	    <!-- Root privilege and Admin privilege can only access action2 page -->
	    <intercept-url pattern="/user" access="!hasRole('ROLE_ADMIN')" />	   	 
	    
	    <!-- Root privilege can only access action3 page  -->
	    <intercept-url pattern="/action3" access="hasRole('ROLE_ROOT')" />
	       
	    
		<!--  <intercept-url pattern="/login" access="permitAll" />  -->
		
		<form-login login-page="/login"
		            default-target-url="/success"
		            authentication-failure-url="/denied" 
		            username-parameter="j_username"
		            password-parameter="j_password"/>
		<logout     logout-success-url="/logout" />
		   
	</http>
	
	<authentication-manager alias="authenticationManager">
	  <authentication-provider user-service-ref="myUserDetailServices">
	   <password-encoder hash="plaintext" > </password-encoder>
	  </authentication-provider>
	</authentication-manager>	
	
 */

@Configuration   
@EnableWebSecurity // enalble spring security configuration
public class SecurityConfig extends WebSecurityConfigurerAdapter   {
	
	// tiem MyUserDetailServices 
	@Autowired
	private MyUserDetailServices myUserDetailServices;
	
	
	// Authorities
	@Autowired
	public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception{
		 auth.userDetailsService(myUserDetailServices); 
	}
	
	// in 27.4.2016, Quan and Phuc spend half of the day to fix error, that prolem is mis this line in SecurityConfig.java
	// Authentication
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		
		http.csrf().disable() //HTTP with Disable CSRF
		    .authorizeRequests()    
		    .antMatchers("/add").access("hasRole('ROLE_ADMIN')")
		    .antMatchers("/action3").access("hasRole('ROLE_USER')")
		    .antMatchers("/").permitAll()
		    .and()
		          .formLogin()
		          .loginProcessingUrl( "/j_spring_security_check" )
		          .loginPage("/login").permitAll()
		          .defaultSuccessUrl("/success")
		          .failureUrl("/login?error")
		          .usernameParameter("j_username")
		          .passwordParameter("j_password");		  		  
		    
		    
	}

}























package com.kscodes.sampleproject.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;


@Controller
public class LoginController {

	
	
	/*------------------>--------------------->---------------------->*/
	// spring security test
	
	@RequestMapping(value={"/","welcome**"},method=RequestMethod.GET)
	public ModelAndView welcome(){
	    ModelAndView model =new ModelAndView();
	    model.addObject("title", "Spring Security Hello World");
	    model.addObject("message", "This is welcome page");
	    model.setViewName("hello");
		
	    return model;
	}
}
